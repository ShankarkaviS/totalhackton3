package com.hcl.ing.hungerbox.util;

public class HungerUtil {

}
