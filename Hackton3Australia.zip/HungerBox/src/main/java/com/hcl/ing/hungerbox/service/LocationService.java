package com.hcl.ing.hungerbox.service;

public interface LocationService {

}
