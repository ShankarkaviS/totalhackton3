package com.hcl.ing.hungerbox.dto;

public class RequestDTO {

}
