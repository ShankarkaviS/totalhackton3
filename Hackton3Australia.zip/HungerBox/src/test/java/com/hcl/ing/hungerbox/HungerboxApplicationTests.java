package com.hcl.ing.hungerbox;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HungerboxApplicationTests {


}
