package com.ing.careconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareconnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareconnectApplication.class, args);
	}

}
