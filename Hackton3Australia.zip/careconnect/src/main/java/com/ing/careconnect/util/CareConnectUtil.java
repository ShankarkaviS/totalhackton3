package com.ing.careconnect.util;

public class CareConnectUtil {

	private CareConnectUtil() {
		
	}
	public static final String DOCTOR_NOT_AVAILABLE = "doctor not available";

}
