package com.hcl.ing.forextransfer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForextransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
