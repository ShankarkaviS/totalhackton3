package com.hcl.ing.forextransfer.util;

public class ForexUtil {

	public static final String CONFIRM_METHOD = "started confirmTransaction method from TransactionController";
	/*public static final " is not available";
	"DEBIT";
	"Pending";
	"CREDIT";*/
	public static final String TRANSACTIONS = "viwTransactionsById method from TransactionController";
		


}
