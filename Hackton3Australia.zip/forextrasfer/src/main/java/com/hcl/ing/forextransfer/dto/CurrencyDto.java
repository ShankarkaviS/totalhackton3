package com.hcl.ing.forextransfer.dto;

public class CurrencyDto {
	
	private Double convertAmount;
	private Double charges;
	
	public Double getConvertAmount() {
		return convertAmount;
	}
	public void setConvertAmount(Double convertAmount) {
		this.convertAmount = convertAmount;
	}
	public Double getCharges() {
		return charges;
	}
	public void setCharges(Double charges) {
		this.charges = charges;
	}
	
	
}
