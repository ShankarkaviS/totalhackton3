package com.hcl.ing.forextransfer.helper;

import java.util.Map;

public class ExchangeRates {
	
	private Map<String, Double> rates;

	public Map<String, Double> getRates() {
		return rates;
	}

	public void setRates(Map<String, Double> rates) {
		this.rates = rates;
	}
}
