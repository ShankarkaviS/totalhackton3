package com.hcl.sandwich.service;

import com.hcl.sandwich.dto.ItemResponseDto;

public interface ItemsService {
	
	ItemResponseDto getAllItems();
}
