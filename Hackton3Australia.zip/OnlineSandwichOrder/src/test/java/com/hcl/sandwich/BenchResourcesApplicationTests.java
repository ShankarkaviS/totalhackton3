package com.hcl.sandwich;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BenchResourcesApplicationTests {

	@Test
	void contextLoads() {
	}

}
