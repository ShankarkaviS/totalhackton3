package com.orange.donateforcause.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonateforcauseApplicationTests {

	@Test
	void contextLoads() {
	}

}
