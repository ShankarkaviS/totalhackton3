package com.orange.donateforcause.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseDto {
	private String message;
	private Integer statusCode;
}
