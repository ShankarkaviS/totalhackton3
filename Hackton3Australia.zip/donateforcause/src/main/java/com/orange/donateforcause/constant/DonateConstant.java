package com.orange.donateforcause.constant;

public class DonateConstant {

	private DonateConstant() {
		
	}
	public static final String DOCTOR_NOT_AVAILABLE = "doctor not available";
	public static final String BLANK_MESSAGE = "Field can't be left blank";
	public static final String VALID_EMAIL = "Provide the valida emailId";

}
