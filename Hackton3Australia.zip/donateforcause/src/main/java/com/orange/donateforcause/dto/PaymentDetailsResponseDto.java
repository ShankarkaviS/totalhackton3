package com.orange.donateforcause.dto;

import java.util.List;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentDetailsResponseDto {
	private List<PaymentDataDto> paymentDetails;	

}
