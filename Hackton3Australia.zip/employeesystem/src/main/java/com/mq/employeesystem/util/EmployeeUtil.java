package com.mq.employeesystem.util;

public class EmployeeUtil {
}