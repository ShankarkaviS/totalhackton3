package com.mq.employeesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeesystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
