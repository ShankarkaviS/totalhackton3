package com.hcl.ing.onlineflightbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineflightbookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
