package com.hcl.ing.onlineflightbooking.exception;

public class SufficientSeatNotAvaliableException  extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	 public  SufficientSeatNotAvaliableException(String exception) {	
			super(exception);
		}

}
