package com.hcl.ing.onlineflightbooking.service;

import com.hcl.ing.onlineflightbooking.dto.LocationResponseDto;

public interface LocationService {
	
	LocationResponseDto getAllLocations(); 

}
