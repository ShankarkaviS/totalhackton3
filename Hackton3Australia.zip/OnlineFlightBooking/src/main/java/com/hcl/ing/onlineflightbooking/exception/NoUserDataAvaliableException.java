package com.hcl.ing.onlineflightbooking.exception;

public class NoUserDataAvaliableException extends Exception{
	private static final long serialVersionUID = 1L;

	 public  NoUserDataAvaliableException(String exception) {	
			super(exception);
		}

}
