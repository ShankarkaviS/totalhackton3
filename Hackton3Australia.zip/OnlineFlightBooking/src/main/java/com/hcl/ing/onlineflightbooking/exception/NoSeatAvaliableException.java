package com.hcl.ing.onlineflightbooking.exception;

public class NoSeatAvaliableException  extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	 public  NoSeatAvaliableException(String exception) {	
			super(exception);
		}

}
