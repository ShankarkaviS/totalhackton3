package com.hcl.ing.onlineflightbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineflightbookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineflightbookingApplication.class, args);
	}

}
