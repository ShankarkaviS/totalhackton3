package com.orange.teleservice.exception;

public class SlotDateRangeException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public SlotDateRangeException(String exception) {
		super(exception);
	}
}
