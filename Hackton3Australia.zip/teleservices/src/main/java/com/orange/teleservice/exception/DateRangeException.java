package com.orange.teleservice.exception;

public class DateRangeException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public DateRangeException(String exception) {
		super(exception);
	}
}
