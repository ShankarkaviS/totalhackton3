package com.orange.teleservice.service;

import com.orange.teleservice.dto.EventResponseDto;

public interface AdEventService {
	public EventResponseDto getAllEvent();
}
