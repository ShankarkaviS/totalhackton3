package com.orange.teleservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeleserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeleserviceApplication.class, args);
	}
}
