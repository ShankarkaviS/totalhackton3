package com.orange.teleservice.util;

public class TeleServiceUtil {

	public TeleServiceUtil() {
		super();
	}

	public static final String LOGIN_METHOD = "login Method in UserController started";
	public static final String LOGIN_SUCCESS = "Login Successfull";
	public static final String INVALID_LOGIN = "Invalid User";
	public static final Integer NOTFOUND_CODE = 404;
}
