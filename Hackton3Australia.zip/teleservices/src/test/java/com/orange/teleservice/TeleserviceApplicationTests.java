package com.orange.teleservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeleserviceApplicationTests {
}
