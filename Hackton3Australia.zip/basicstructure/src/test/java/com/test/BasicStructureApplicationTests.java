package com.test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasicStructureApplicationTests {

}
